source("Setup.R")
source("LoadCSV.R")
# Sprawdzić, czy obroty firm w badanych województwach mają rozkłady normalne test zgodności Kołmogorowa - Lillieforsa,
# przyjąć poziom istotności ALPHA = 0.05.



#-------------------------------------------------------------------------------------#
# Sprawdzić, czy obroty firm w badanych województwach mają rozkłady normalne          #
# (test zgodności Kołmogorowa - Lillieforsa, przyjąć poziom istotności ALPHA = 0.05.) #
#-------------------------------------------------------------------------------------#

# Ten test to modyfikacja testu Kołmogorowa - Smirnowa zaproponowana przez Huberta Lillieforsa[Lilliefors1967],
# pozwalająca na testowanie zgodności z całą rodziną rozkładów normalnych,
# bez znajomości parametrów średniej i odchylenia standardowego
# (test Kołmogorowa - Smirnowa pozwala na zbadanie zgodności z jednym określonym rozkładem).

# Statystyka testowa w przypadku testu Lillieforsa wygląda tak samo jak w przypadku testu Kołmogorowa Smirnowa.
# Różnica polega na zastosowaniu innego rozkładu dla statystyki testowej(przybliżenie rozkładu dokładnego),
# uwzględniającego to, że hipoteza zerowa jest hipotezą złożoną.

# https://pqstat.pl/?mod_f=normalnosci
# https://www.rdocumentation.org/packages/nortest/versions/1.0-4/topics/lillie.test
# https://influentialpoints.com/notes/narmb1b.htm
# http://smarterpoland.pl/index.php/2013/04/wybrane-testy-normalnoci/
# https://github.com/cran/nortest/blob/master/R/lillie.test.R
# https://github.com/cran/nortest/blob/master/man/lillie.test.Rd



#------------------------------------------#
# Test zgodności Kołmogorowa - Lillieforsa #
#------------------------------------------#
# STR: 4 - https://cran.r-project.org/web/packages/nortest/nortest.pdf
# CODE   - https://github.com/cran/nortest/blob/master/R/lillie.test.R
# TABLE  - https://www.real-statistics.com/statistics-tables/lilliefors-test-table/

writeLines("---- Hipotezy ----\n")
writeLines("Hipoteza 0\nRozkład cechy statystycznej jest rozkładem normalnym.\n")
writeLines("Hipoteza Alt\nRozkład cechy statystycznej nie jest rozkładem normalnym.\n")



#------------------------------#
#            ŚLĄSKIE           #
#------------------------------#

li <- lillie.test(Data_Sl)
D_SL <- li[1] # Wartość D

writeLines("---- Test dla Śląska ----\n")
if (P > D_SL) {
  writeLines("Brak podstaw do odrzucenia Hipotezy 0.")
  writeLines("Dane maja rozklad normalny.\n")
} else {
  writeLines("Istnieja podstawy do odrzucenia Hipotezy 0.")
  writeLines("Dane nie maja rozkladu normalnego.\n")
}



#------------------------------#
#          MAZOWICEKIE         #
#------------------------------#

li <- lillie.test(Data_Maz)
D_MAZ <- li[1] # Wartość D 

writeLines("---- Test dla Mazowsza ----\n")
if (P > D_MAZ) {
  writeLines("Brak podstaw do odrzucenia Hipotezy 0.")
  writeLines("Dane maja rozklad normalny.\n")
} else {
  writeLines("Istnieja podstawy do odrzucenia Hipotezy 0.")
  writeLines("Dane nie maja rozkladu normalnego.\n")
}