source("Setup.R")
source("LoadCSV.R")
# Dokonać estymacji przedziałowej średnich obrotów firm województwa śląskiego.
# Przyjąć poziom ufności 1-Alpha=0.95. Obliczyć względną precyzję oszacowania i sprawdzić,
# czy mamy podstawy do uogólniania otrzymanego przedziału ufności na całą populację małych firm.



#------------------------------------------------------------------------------#
# Dokonać estymacji przedziałowej średnich obrotów firm województwa śląskiego. #
# Przyjąć poziom ufności 1-Alpha=0.95.                                         #
#------------------------------------------------------------------------------#

# Wzór dla drugiej
# http://home.agh.edu.pl/~bartus/index.php?action=dydaktyka&subaction=statystyka&item=analiza_danych_5
# Wzór na ten przedział ufności
# https://media.discordapp.net/attachments/966024977591701534/971416591558381578/unknown.png
# Tablice z różnymi rozkładami 
# https://pracownik.kul.pl/files/12167/public/wnioskowanie/tabliceZebrane.pdf

SL_srednia  <- mean(Data_Sl) # Średnia Śląsk
SL_odch_std <- sd(Data_Sl)   # Odchylenie std Śląsk (jak szeroko wartości jakiejś wielkości są rozrzucone wokół jej średniej)
wsp_ufnosci <- alphaNeg      # -> LoadCSV.R
t_student   <- 2.042         # Wartość odczytana z tablicy t-studenta dla n-1 stopni swobody

Sl_dolnaGranica <- SL_srednia - (t_student * (SL_odch_std / sqrt(n))) # Wzór dla drugiej ilości
Sl_gornaGranica <- SL_srednia + (t_student * (SL_odch_std / sqrt(n)))

cat("Przedział ufności małych firm w wojewodztwie Śląskim:\n")
cat(Sl_dolnaGranica, "< m <", Sl_gornaGranica, "\n\n")



#------------------------------------------------------------------------------------------------#
# Obliczyć względną precyzję oszacowania i sprawdzić,                                            #
# czy mamy podstawy do uogólniania otrzymanego przedziału ufności na całą populację małych firm. #
#------------------------------------------------------------------------------------------------#

# Wzór na te względną precyzje
# http://matma-po-ludzku.pl/statystyka/wnioskowanie/estymacja/estymacja_sredniej/zadanie27.php
# https://cdn.discordapp.com/attachments/912455085378904136/972152962166186034/unknown.png

# Jeśli względna precyzja szacunku wynosi mniej niż 5% to wnioskowanie jest uprawnione i całkowicie bezpieczne 
wzgl_precyzja <- 1/2 * ((Sl_gornaGranica - Sl_dolnaGranica) / SL_srednia)

cat("Względna precyzja oszacowań wynosi: ", wzgl_precyzja, "\n\n")
