source("Setup.R")
source("LoadCSV.R")
# Dokonać analizy struktury obrotów firm w obu województwach wyznaczając:
# miary położenia, zróżnicowania (dyspersji), asymetrii i skupienia dla szeregu szczegółowego.
# Następnie zbudować 2 szeregi rozdzielcze (dla każdego województwa) i wykonać histogramy rozkładów empirycznych.
# W oparciu o odpowiednio wybrane miary (jakie) oraz histogramy porównać obroty firm w województwie śląskim i mazowieckim.

summaryTable <- data.frame(matrix(ncol=2, nrow=0, dimnames = list(NULL, c("Śląskie", "Mazowieckie"))))



#------------------------------#
#       Miary położenia        #
#------------------------------#
# STR: 94 - "Wykłady z metod statystycznych"
summaryTable["1. Miary położenia", ] <- c(
  "",
  ""
)

# 1. Średnia Arytmetyczna
summaryTable["Średnia_Arytmetyczna", ] <- c(
  round(mean(Data_Sl),  roundTo),
  round(mean(Data_Maz), roundTo)
)

# 2. Dominanta
summaryTable["Dominanta", ] <- c(
  toString(Mode(Data_Sl)),
  toString(Mode(Data_Maz))
)

# 3. Mediana
summaryTable["Mediana", ] <- c(
  round(median(Data_Sl), roundTo),
  round(median(Data_Maz), roundTo)
)

# 4. Kwantyle 1 i 3 stopnia
kwanPierwszySl  <- quantile(Data_Sl,  0.25)
kwanPierwszyMaz <- quantile(Data_Maz, 0.25)
summaryTable["Kwantyl st.1", ] <- c(
  round(kwanPierwszySl, roundTo),
  round(kwanPierwszyMaz, roundTo)
)

kwanTrzeciSl  <- quantile(Data_Sl,  0.75)
kwanTrzeciMaz <- quantile(Data_Maz, 0.75)
summaryTable["Kwantyl st.3", ] <- c(
  round(kwanTrzeciSl, roundTo),
  round(kwanTrzeciMaz, roundTo)
)

# 5. Decyle
# Dwie tabelki
decylSl  <- quantile(Data_Sl, seq(.1, .9, by = .1))
decylMaz <- quantile(Data_Maz, seq(.1, .9, by = .1))



#------------------------------#
#   Zróżnicowanie (dyspersja)  #
#------------------------------#
# STR: 95 - "Wykłady z metod statystycznych"
summaryTable["2. Zróżnicowanie", ] <- c(
  "",
  ""
)

# Odchylenie standardowe
summaryTable["Odchylenie_standardowe", ] <- c(
  round(sd(Data_Sl),  roundTo),
  round(sd(Data_Maz), roundTo)
)

# Wariancja nieobciążona
summaryTable["Wariancja_nieobciążona", ] <- c(
  round(var(Data_Sl),  roundTo),
  round(var(Data_Maz), roundTo)
)

# Wariancja obciążona
summaryTable["Wariancja_obciążona", ] <- c(
  round(var(Data_Sl)  * ((n - 1) / n), roundTo),
  round(var(Data_Maz) * ((n - 1) / n), roundTo)
)

# Współczynnik zmienności
summaryTable["Współczynnik_zmienności", ] <- c(
  round(as.numeric(summaryTable["Odchylenie_standardowe", ]$Śląskie)     * 100 / as.numeric(summaryTable["Średnia_Arytmetyczna", ]$Śląskie),     roundTo),
  round(as.numeric(summaryTable["Odchylenie_standardowe", ]$Mazowieckie) * 100 / as.numeric(summaryTable["Średnia_Arytmetyczna", ]$Mazowieckie), roundTo)
)

# Rozstęp
summaryTable["Rozstęp", ] <- c(
  round(max(Data_Sl)  - min(Data_Sl),  roundTo),
  round(max(Data_Maz) - min(Data_Maz), roundTo)
)

# Odchylenie ćwiartkowe
summaryTable["Rozstęp", ] <- c(
  round((kwanTrzeciSl  - kwanPierwszySl)  / 2, roundTo),
  round((kwanTrzeciMaz - kwanPierwszyMaz) / 2, roundTo)
)



#------------------------------#
#           Asymetria          #
#------------------------------#
# STR: 96 - "Wykłady z metod statystycznych"
summaryTable["3. Asymetria", ] <- c(
  "",
  ""
)

# Współczynnik skośności 
wsp_skosnosc_Sl  <- 3 * (as.numeric(summaryTable["Średnia_Arytmetyczna", ]$Śląskie)     - as.numeric(summaryTable["Mediana", ]$Śląskie))     / as.numeric(summaryTable["Odchylenie_standardowe", ]$Śląskie)
wsp_skosnosc_Maz <- 3 * (as.numeric(summaryTable["Średnia_Arytmetyczna", ]$Mazowieckie) - as.numeric(summaryTable["Mediana", ]$Mazowieckie)) / as.numeric(summaryTable["Odchylenie_standardowe", ]$Mazowieckie)
# Wynik jest < 0 co oznacza, że rozkład cechy jest asymetryczny lewostronnie
summaryTable["Współczynnik_skośności ", ] <- c(
  round(wsp_skosnosc_Sl,  roundTo),
  round(wsp_skosnosc_Maz, roundTo)
)

#Skośność 
summaryTable["Skośność ", ] <- c(
  round(skewness(Data_Sl),  roundTo),
  round(skewness(Data_Maz), roundTo)
)



#-------------------------------------#
# Skupienie dla szeregu szczegółowego #
#-------------------------------------#
# STR: 96 - "Wykłady z metod statystycznych"
summaryTable["4. Skupienie dla szeregu szczegółowego", ] <- c(
  "",
  ""
)

# Kurtoza
summaryTable["Kurtoza ", ] <- c(
  round(kurtosis(Data_Sl),  roundTo),
  round(kurtosis(Data_Maz), roundTo)
)



#--------------------------------------------------------------------------------#
# Zbudować 2 szeregi rozdzielcze i wykonać histogramy dla rozkładów empirycznych #
#--------------------------------------------------------------------------------#
# STR: 97 - "Wykłady z metod statystycznych"
# STR: 9 - https://www-users.mat.umk.pl/~iggypop/statystyka_opisowa_w_R.pdf

# Różnica pomiędzy max i min - Wyznaczamy zakres wartości minimalnych i maksymalnych
max_Sl     <- max(Data_Sl)
min_Sl     <- min(Data_Sl)
max_Maz    <- max(Data_Maz)
min_Maz    <- min(Data_Maz)
zakres_Sl  <- max_Sl  - min_Sl
zakres_Maz <- max_Maz - min_Maz

# Szerokość przedziału klasowego - Ile słupków pojawi się na wykresie
szerPrzedK_Sl  <- zakres_Sl / 10
szerPrzedK_Maz <- zakres_Maz / 10

# Punkty przecięcia
punktPrzeciecia_Sl  <- seq(min_Sl,  max_Sl  + 0.1, by = szerPrzedK_Sl)
punktPrzeciecia_Maz <- seq(min_Maz, max_Maz + 0.1, by = szerPrzedK_Maz)

# Przedziały
przedzial_Sl  <- cut(Data_Sl,  punktPrzeciecia_Sl,  right = FALSE, include.lowest = TRUE)
przedzial_Maz <- cut(Data_Maz, punktPrzeciecia_Maz, right = FALSE, include.lowest = TRUE)

# Szereg rozdzielczy
szRozdz_Sl  <- table(przedzial_Sl)
szRozdz_Maz <- table(przedzial_Maz)



#------------------------------#
#          Histogramy          #
#------------------------------#

# Kolory wykresów
c1 <- rgb(173,216,230, max = 255, alpha = 80, names = "lt.blue")
c2 <- rgb(255,192,203, max = 255, alpha = 80, names = "lt.pink")

# Dwie kolumny
par(mfrow = c(1,2))

# Histogram pierwszy SL
hist(Data_Sl, breaks = punktPrzeciecia_Sl, col = c1, main = "Śląsk", xlab = "Punkty przecięć", ylab = "Częstość występowania", axes = F)
axis(2) # axis() osie x i y
axis(1, at = seq(min_Sl, max_Sl, by=szerPrzedK_Sl), labels = seq(min_Sl, max_Sl, by = szerPrzedK_Sl))

# Histogram pierwszy MAZ
hist(Data_Maz, breaks = punktPrzeciecia_Maz, col = c2, main = "Mazowieckie", xlab = "Punkty przecięć", ylab = "", axes = F)
axis(2)
axis(1, at = seq(min_Maz, max_Maz, by=szerPrzedK_Maz), labels = seq(min_Maz, max_Maz, by = szerPrzedK_Maz))



#-------------------------------------------------#
# Porównanie firm o wybrane miary oraz histogramy #
#-------------------------------------------------#
print(summaryTable)

writeLines("")
writeLines("Decyle Śląsk:")
print(decylSl)
writeLines("")
writeLines("Decyle Mazowieckie:")
print(decylMaz)