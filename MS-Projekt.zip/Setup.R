if (!require("DescTools")) install.packages("DescTools") # https://www.rdocumentation.org/packages/DescTools/versions/0.99.44 
if (!require("nortest"))   install.packages("nortest")   # https://cran.r-project.org/web/packages/nortest/nortest.pdf
#if (!require("moments"))   install.packages("moments")   # https://cran.r-project.org/web/packages/moments/
# skewness (Odrzucone)
# kurtosis (Odrzucone)
if (!require("e1071"))     install.packages("e1071")     # https://www.r-tutor.com/elementary-statistics/numerical-measures
# skewness
# kurtosis