source("Setup.R")
source("LoadCSV.R")
# Dokonać estymacji przedziałowej wariancji obrotów dla województwa mazowieckiego.
# Przyjąć poziom ufności 1-Alpha=0.95. Obliczyć względną precyzję oszacowania i sprawdzić,
# czy mamy podstawy do uogólniania otrzymanego przedziału ufności na całą populację małych firm.



#----------------------------------------------------------------------------------#
# Dokonać estymacji przedziałowej wariancji obrotów dla województwa mazowieckiego. #
# Przyjąć poziom ufności 1-Alpha=0.95.                                             #
#----------------------------------------------------------------------------------#

# Populacja : małe firmy w województwie Mazowieckim
# Próbka : 31 firm

# Wariancja wzór
# https://cdn.discordapp.com/attachments/912455085378904136/971843130250891274/unknown.png
# http://matma-po-ludzku.pl/statystyka/wnioskowanie/estymacja/estymacja_wariancja/zadanie1.php
# http://www.statystyka.org/statys/ep/eptp.htm

wariancja_Maz   <- var(Data_Maz) * ((n-1)/n) # Wariancja obciążona Mazowieckie (określa ona rozrzut wokół pomiarów średnich)
wsp_ufnosci     <- alphaNeg
chi_kwadrat_jed <- 46.9792 # chi^2 dla Alpha / 2    2  n - 1 = 30 stopni swobody (jest to najmniejsza liczba niezależnych od siebie zmiennych)
chi_kwadrat_dwa <- 16.7908 # chi^2 dla 1-Alpha / 2  1  30 stopni swobody

# Wzór na te estymacje -  dla dużych wartości 
# https://cdn.discordapp.com/attachments/912455085378904136/971849387913400360/unknown.png
Maz_dolnaGranica <- (n * wariancja_Maz) / chi_kwadrat_jed 
Maz_gornaGranica <- (n * wariancja_Maz) / chi_kwadrat_dwa


cat("Przedzial ufnosci malych firm w wojewodztwie Mazowieckim:\n")
cat(Maz_dolnaGranica,"< wariancja <", Maz_gornaGranica,"\n\n")



#------------------------------------------------------------------------------------------------#
# Obliczyć względną precyzję oszacowania i sprawdzić,                                            #
# czy mamy podstawy do uogólniania otrzymanego przedziału ufności na całą populację małych firm. #
#------------------------------------------------------------------------------------------------#

wzgl_precyzja <- 0.5 * ((Maz_gornaGranica - Maz_dolnaGranica) / wariancja_Maz)

cat("Względna precyzja oszacowań wynosi: ", wzgl_precyzja, "\n\n")