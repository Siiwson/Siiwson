# Poprawniejsze przypisanie .csv do zmiennej
#Data_all <- read.csv(file.choose(), sep = ";")
#Data_sl <- read.csv(file.choose())
#Data_maz <- read.csv(file.choose())

# Statyczne przypisanie pliku
CSV_Data <- read.csv("zestaw_4_data.csv", sep=";")
Data_Sl  <- CSV_Data$Sl
Data_Maz <- CSV_Data$Maz

#-------#
# Stałe #
#-------#

# Ilość prób
n <- 31

# Alpha
alpha <-  0.05

# Alpha Neg
alphaNeg <- 1 - alpha

# Zaokrąglenie do
roundTo <- 8

# https://www.real-statistics.com/statistics-tables/lilliefors-test-table/
# Kol 0.05, Row 31
# Wartość P
P <- 0.1559