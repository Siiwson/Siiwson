source("Setup.R")
source("LoadCSV.R")
# Firmy którego województwa są bardziej efektywne?
# Należy sformułować i zweryfikować odpowiednią hipotezę na poziomie istotności Alpha=0.05.



#-------------------------------------------------------------------------------------------#
# Firmy którego województwa są bardziej efektywne?                                          #
# Należy sformułować i zweryfikować odpowiednią hipotezę na poziomie istotności Alpha=0.05. #
#-------------------------------------------------------------------------------------------#

writeLines("---- Hipotezy ----\n")
writeLines("Hipoteza 0\nEfektywność województwa Śląskiego jest równa efektywności Mazowieckiego.\n")
writeLines("Hipoteza Alt\nEfektywność województwa Śląskiego nie jest równa od efektywności Mazowieckiego.\n")

test <- t.test(Data_Sl, Data_Maz, var.equal = TRUE)

writeLines("---- Wynik testu ----\n")
if (test$p.value == 0) {
  writeLines("Brak podstaw do odrzucenia Hipotezy 0.")
  writeLines("Efektywność województwa Śląskiego jest równa efektywności Mazowieckiego.\n")
} else {
  writeLines("Istnieja podstawy do odrzucenia Hipotezy 0.")
  writeLines("Efektywność województwa Śląskiego nie jest równa od efektywności Mazowieckiego.\n")
  
  if (test$estimate[1] > test$estimate[2]) {
    writeLines("Województwo Ślaskie jest bardziej efektywniejsze.")
  } else {
    writeLines("Województwo Mazowieckie jest bardziej efektywniejsze.")
  }
}